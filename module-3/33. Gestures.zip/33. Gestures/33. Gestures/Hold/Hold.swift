//
//  Hold.swift
//  33. Gestures
//
//  Created by Despo on 18.12.24.
////
//
//import SwiftUI
//
//struct Hold: View {
//    let vm = WheelViewModel()
//    
//    var body: some View {
//        VStack {
//            ZStack {
//                ForEach(0..<vm.segmentCount, id: \.self) { index in
//                    let startAngle = vm.createStartAngle(with: index)
//                    let endAngle = vm.createEndAngle(with: index)
//                    
//                    WheelModel(
//                        startAngle: .degrees(startAngle),
//                        endAngle: .degrees(endAngle)
//                    )
//                    .fill(vm.colors[index % vm.colors.count])
//                }
//            }
//            
//        }
//        .padding()
//    }
//    
//    #Preview {
//        Hold()
//    }
