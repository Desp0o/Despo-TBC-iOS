//
//  WheelViewModel.swift
//  33. Gestures
//
//  Created by Despo on 18.12.24.
//

import SwiftUI

final class WheelViewModel {
    let segmentCount = 14
    
    let colors = [
        Color.red,
        Color.orange,
        Color.yellow,
        Color.green,
        Color.blue,
        Color.purple,
        Color.pink,
        Color.brown,
        Color.gray,
        Color.black,
        Color.cyan,
        Color.mint,
        Color.teal,
        Color.indigo
    ]
    
    func createStartAngle(with index: Int) -> Double {
        Double(index) / Double(segmentCount) * 360
    }
    
    func createEndAngle(with index: Int) -> Double {
        Double(index + 1) / Double(segmentCount) * 360
    }
    
    func makeWheelSpin() -> Double {
        360 * 5 + Double.random(in: 0..<360)
    }
}
