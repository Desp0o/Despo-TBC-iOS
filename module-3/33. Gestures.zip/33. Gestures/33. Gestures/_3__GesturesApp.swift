//
//  _3__GesturesApp.swift
//  33. Gestures
//
//  Created by Despo on 18.12.24.
//

import SwiftUI

@main
struct _3__GesturesApp: App {
    var body: some Scene {
        WindowGroup {
            WheelSpin()
        }
    }
}
